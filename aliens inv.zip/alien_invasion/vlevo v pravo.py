if event.key == pygame.K_RIGHT:
    self.ship.moving_right = True
elif event.key == pygame.K_LEFT:
    self.ship.moving_left = True











if event.key == pygame.K_RIGHT:
    self.ship.moving_right = False
elif event.key == pygame.K_LEFT:
    self.ship.moving_left = False